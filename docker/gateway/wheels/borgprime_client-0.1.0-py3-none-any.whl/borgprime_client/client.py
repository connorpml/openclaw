"""BorgPrime REST API client."""

from ._http import _Session
from .resources.parts import PartsResource
from .resources.ledger import LedgerResource, TagsResource
from .resources.orders import (
    PurchaseOrdersResource,
    SalesOrdersResource,
    ManufacturingOrdersResource,
)
from .resources.businesses import BusinessesResource
from .resources.shipments import ShipmentsResource
from .resources.serial_numbers import SerialNumbersResource
from .resources.designs import DesignsResource
from .resources.prefixes import PrefixesResource
from .resources.settings import SettingsResource
from .resources.issues import IssuesResource


class BorgPrimeClient:
    """Client for BorgPrime REST API.

    Provides access to inventory parts, ledger entries, orders, and other
    BorgPrime resources. All mutation operations on draft-gated resources
    are protected by draft mode checks.
    """

    def __init__(self, base_url: str, timeout: int = 10, include_thumbnails: bool = False):
        """Initialize BorgPrime client.

        Args:
            base_url: Base URL of BorgPrime API (e.g., "http://localhost:5000")
            timeout: Request timeout in seconds (default: 10)
            include_thumbnails: If True, include thumbnail_data in responses. Default False
                strips thumbnail fields to keep responses concise (important for AI agents).
        """
        http = _Session(base_url, timeout, include_thumbnails=include_thumbnails)
        self.parts = PartsResource(http)
        self.ledger = LedgerResource(http)
        self.tags = TagsResource(http)
        self.purchase_orders = PurchaseOrdersResource(http)
        self.sales_orders = SalesOrdersResource(http)
        self.manufacturing_orders = ManufacturingOrdersResource(http)
        self.businesses = BusinessesResource(http)
        self.shipments = ShipmentsResource(http)
        self.serial_numbers = SerialNumbersResource(http)
        self.designs = DesignsResource(http)
        self.prefixes = PrefixesResource(http)
        self.settings = SettingsResource(http)
        self.issues = IssuesResource(http)

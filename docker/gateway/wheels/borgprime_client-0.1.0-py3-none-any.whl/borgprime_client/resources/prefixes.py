"""Prefixes resource for BorgPrime API."""

from ._base import BaseResource


class PrefixesResource(BaseResource):
    """Resource for managing prefixes (ungated)."""

    _base_path = "/api/prefixes"

    def list(self, sort_by=None, sort_order=None):
        """List all prefixes.

        Args:
            sort_by: Field name to sort by (optional)
            sort_order: Sort direction: 'asc' or 'desc' (optional)

        Returns:
            List of prefix dicts
        """
        params = {}
        if sort_by is not None:
            params["sort_by"] = sort_by
        if sort_order is not None:
            params["sort_order"] = sort_order
        return self._http.get(self._base_path, params=params if params else None)

    def create(self, **kwargs):
        """Create a new prefix.

        Args:
            **kwargs: Prefix fields

        Returns:
            Created prefix dict
        """
        return self._http.post(self._base_path, json=kwargs)

    def update(self, code, **kwargs):
        """Update a prefix.

        Args:
            code: Prefix code
            **kwargs: Fields to update

        Returns:
            Updated prefix dict
        """
        return self._http.put(f"{self._base_path}/{code}", json=kwargs)

    def delete(self, code):
        """Delete a prefix.

        Args:
            code: Prefix code

        Returns:
            Response dict
        """
        return self._http.delete(f"{self._base_path}/{code}")

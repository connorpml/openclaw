"""Order resources for BorgPrime API."""

from ..exceptions import DraftOnlyError
from ._base import DraftResource, _apply_limit, _validate_id


class _OrderResourceBase(DraftResource):
    """Base class for order resources with standard CRUD operations."""

    _base_path: str  # Set by subclass
    _id_kwarg = "order_id"

    def list(self, q=None, limit=None, offset=None, sort_by=None, sort_order=None):
        """List orders with optional filters.

        Args:
            q: Search query string (optional)
            limit: Maximum number of results (optional)
            offset: Result offset (optional)
            sort_by: Field name to sort by (optional)
            sort_order: Sort direction: 'asc' or 'desc' (optional)

        Returns:
            List of order dicts
        """
        params = {}
        if q is not None:
            params["q"] = q
        if offset is not None:
            params["offset"] = offset
        _apply_limit(params, limit)
        if sort_by is not None:
            params["sort_by"] = sort_by
        if sort_order is not None:
            params["sort_order"] = sort_order
        return self._http.get(self._base_path, params=params)

    def get(self, order_id):
        """Get a single order by ID.

        Args:
            order_id: Order ID

        Returns:
            Order dict
        """
        _validate_id(order_id, "order_id")
        return self._http.get(f"{self._base_path}/{order_id}")

    def create(self, **kwargs):
        """Create a new order (always as draft).

        Args:
            **kwargs: Order fields

        Returns:
            Created order dict

        Raises:
            DraftOnlyError: If is_draft=False is passed
        """
        if kwargs.get("is_draft") is False:
            raise DraftOnlyError("Cannot create a non-draft entity via borgprime_client.")
        kwargs["is_draft"] = True
        return self._http.post(self._base_path, json=kwargs)

    def update(self, order_id, **kwargs):
        """Update an order (only if draft).

        Args:
            order_id: Order ID
            **kwargs: Fields to update

        Returns:
            Updated order dict

        Raises:
            DraftOnlyError: If order is not a draft
        """
        self._assert_draft(order_id)
        return self._http.put(f"{self._base_path}/{order_id}", json=kwargs)

    def delete(self, order_id):
        """Delete an order (only if draft).

        Args:
            order_id: Order ID

        Returns:
            Response dict

        Raises:
            DraftOnlyError: If order is not a draft
        """
        self._assert_draft(order_id)
        return self._http.delete(f"{self._base_path}/{order_id}")


class PurchaseOrdersResource(_OrderResourceBase):
    """Resource for managing purchase orders."""

    _base_path = "/api/purchase-orders"


class SalesOrdersResource(_OrderResourceBase):
    """Resource for managing sales orders."""

    _base_path = "/api/sales-orders"


class ManufacturingOrdersResource(_OrderResourceBase):
    """Resource for managing manufacturing orders."""

    _base_path = "/api/manufacturing-orders"

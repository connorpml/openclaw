"""Designs resource for BorgPrime API."""

from ._base import BaseResource


class DesignsResource(BaseResource):
    """Resource for reading designs (read-only)."""

    _base_path = "/api/designs"

    def list(self):
        """List all designs.

        Returns:
            List of design dicts
        """
        return self._http.get(self._base_path)

    def get(self, design_id):
        """Get a single design by ID.

        Args:
            design_id: Design ID

        Returns:
            Design dict
        """
        return self._http.get(f"{self._base_path}/{design_id}")

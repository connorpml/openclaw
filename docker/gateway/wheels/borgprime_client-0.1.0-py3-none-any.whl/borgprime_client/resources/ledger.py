"""Ledger and tags resources for BorgPrime API."""

from ..exceptions import DraftOnlyError
from ._base import BaseResource, DraftResource, _validate_id


class LedgerResource(DraftResource):
    """Resource for managing inventory ledger entries."""

    _base_path = "/api/ledger"
    _id_kwarg = "ledger_id"

    def list(self, part_id=None, type=None, start=None, end=None, search=None, limit=None, include_takes=False, sort_by=None, sort_order=None, purchase_order_id=None, sales_order_id=None, manufacturing_order_id=None, shipment_id=None):
        """List ledger entries with filters.

        The ledger corpus is large (thousands of entries). At least one filter
        (part_id, type, start, end, search) OR an explicit limit= is required to
        prevent fetching the entire table.

        Args:
            part_id: Filter by part ID (integer)
            type: Filter by entry type (MAKE, TAKE, RECEIVE, SHIP, ADJUST)
            start: ISO date filter for start_date (inclusive)
            end: ISO date filter for end_date (inclusive)
            search: Full-text search across part number, notes, type, tags
            limit: Max results (default 100, max 500 — enforced at DB level)
            include_takes: If False (default), TAKE entries are excluded from results.
                TAKE entries are stock pulls driven by parent MAKE entries; the MAKE
                is the meaningful unit. Pass include_takes=True to see raw consumption.
            sort_by: Field name to sort by (optional)
            sort_order: Sort direction: 'asc' or 'desc' (optional)
            purchase_order_id: Filter by linked purchase order integer ID (optional)
            sales_order_id: Filter by linked sales order integer ID (optional)
            manufacturing_order_id: Filter by linked manufacturing order integer ID (optional)
            shipment_id: Filter by linked shipment integer ID (optional)

        Returns:
            List of ledger entry dicts

        Raises:
            ValueError: If no filter and no explicit limit are provided
        """
        has_filter = any(v is not None for v in (part_id, type, start, end, search, purchase_order_id, sales_order_id, manufacturing_order_id, shipment_id))
        if not has_filter and limit is None:
            raise ValueError(
                "ledger.list() requires at least one filter (part_id=, type=, start=, "
                "end=, search=) or an explicit limit= to avoid fetching the entire corpus. "
                "Example: ledger.list(type='MAKE') or ledger.list(limit=50)"
            )
        params = {}
        if part_id is not None:
            params["part_id"] = part_id
        if type is not None:
            params["type"] = type
        if start is not None:
            params["start"] = start
        if end is not None:
            params["end"] = end
        if search is not None:
            params["search"] = search
        effective_limit = min(int(limit), 500) if limit is not None else 100
        params["limit"] = effective_limit
        if sort_by is not None:
            params["sort_by"] = sort_by
        if sort_order is not None:
            params["sort_order"] = sort_order
        if purchase_order_id is not None:
            params["purchase_order_id"] = purchase_order_id
        if sales_order_id is not None:
            params["sales_order_id"] = sales_order_id
        if manufacturing_order_id is not None:
            params["manufacturing_order_id"] = manufacturing_order_id
        if shipment_id is not None:
            params["shipment_id"] = shipment_id
        result = self._http.get(self._base_path, params=params)
        if not include_takes and type is None:
            result = [e for e in result if e.get("type") != "TAKE"]
        return result

    def get(self, ledger_id):
        """Get a single ledger entry by ID.

        Args:
            ledger_id: Ledger entry ID

        Returns:
            Ledger entry dict
        """
        _validate_id(ledger_id, "ledger_id")
        return self._http.get(f"{self._base_path}/{ledger_id}")

    def create(self, **kwargs):
        """Create a new ledger entry (always as draft).

        Args:
            **kwargs: Entry fields

        Returns:
            Created entry dict

        Raises:
            DraftOnlyError: If is_draft=False is passed
        """
        if kwargs.get("is_draft") is False:
            raise DraftOnlyError("Cannot create a non-draft entity via borgprime_client.")
        kwargs["is_draft"] = True
        return self._http.post(self._base_path, json=kwargs)

    def update(self, ledger_id, **kwargs):
        """Update a ledger entry (only if draft).

        Args:
            ledger_id: Entry ID
            **kwargs: Fields to update

        Returns:
            Updated entry dict

        Raises:
            DraftOnlyError: If entry is not a draft
        """
        self._assert_draft(ledger_id)
        return self._http.put(f"{self._base_path}/{ledger_id}", json=kwargs)

    def delete(self, ledger_id):
        """Delete a ledger entry (only if draft).

        Args:
            ledger_id: Entry ID

        Returns:
            Response dict

        Raises:
            DraftOnlyError: If entry is not a draft
        """
        self._assert_draft(ledger_id)
        return self._http.delete(f"{self._base_path}/{ledger_id}")

    def bulk_update_as_draft(self, ledger_ids, **fields):
        """Stage the same field updates on multiple ledger entries in one request.

        Calls PUT /api/ledger/bulk?draft=true with a per-entry updates list
        built from ledger_ids + shared fields.  The backend snapshots each
        entry before applying changes, so all updates can be approved or
        rejected individually via the normal approve/reject-update routes.

        Draft entries (is_draft=True) are rejected server-side; only live
        entries are eligible for draft staging.

        Args:
            ledger_ids: List of integer ledger entry IDs to update
            **fields: Fields to apply to every entry (e.g. status="FINISHED")

        Returns:
            List of updated entry dicts (each with pre_update_snapshot set)
        """
        updates = [{"id": lid, **fields} for lid in ledger_ids]
        result = self._http.put(
            self._base_path + "/bulk",
            json={"updates": updates},
            params={"draft": "true"},
        )
        if isinstance(result, dict):
            return result.get("updated", result)
        return result

    def make(self, **kwargs):
        """Create a MAKE ledger entry (always as draft).

        Convenience wrapper that delegates to create() with type='MAKE'.

        Args:
            **kwargs: Entry fields (e.g., part_id, quantity, start_date)

        Returns:
            Created entry dict

        Raises:
            DraftOnlyError: If is_draft=False is passed
        """
        kwargs["type"] = "MAKE"
        return self.create(**kwargs)

    def ship(self, **kwargs):
        """Create a SHIP ledger entry (always as draft).

        Convenience wrapper that delegates to create() with type='SHIP'.

        Args:
            **kwargs: Entry fields (e.g., part_id, quantity)

        Returns:
            Created entry dict

        Raises:
            DraftOnlyError: If is_draft=False is passed
        """
        kwargs["type"] = "SHIP"
        return self.create(**kwargs)


class TagsResource(BaseResource):
    """Resource for managing tags (ungated)."""

    _base_path = "/api/tags"

    def list(self, sort_by=None, sort_order=None):
        """List all tags.

        Args:
            sort_by: Field name to sort by (optional)
            sort_order: Sort direction: 'asc' or 'desc' (optional)

        Returns:
            List of tag dicts
        """
        params = {}
        if sort_by is not None:
            params["sort_by"] = sort_by
        if sort_order is not None:
            params["sort_order"] = sort_order
        return self._http.get(self._base_path, params=params if params else None)

    def get(self, tag_id):
        """Get a single tag by ID.

        Args:
            tag_id: Tag ID

        Returns:
            Tag dict
        """
        return self._http.get(f"{self._base_path}/{tag_id}")

    def create(self, **kwargs):
        """Create a new tag.

        Args:
            **kwargs: Tag fields

        Returns:
            Created tag dict
        """
        return self._http.post(self._base_path, json=kwargs)

    def update(self, tag_id, **kwargs):
        """Update a tag.

        Args:
            tag_id: Tag ID
            **kwargs: Fields to update

        Returns:
            Updated tag dict
        """
        return self._http.put(f"{self._base_path}/{tag_id}", json=kwargs)

    def delete(self, tag_id):
        """Delete a tag.

        Args:
            tag_id: Tag ID

        Returns:
            Response dict
        """
        return self._http.delete(f"{self._base_path}/{tag_id}")

"""Shipments resource for BorgPrime API."""

from ..exceptions import DraftOnlyError
from ._base import DraftResource, _apply_limit, _validate_id


class ShipmentsResource(DraftResource):
    """Resource for managing shipments."""

    _base_path = "/api/shipments"
    _id_kwarg = "shipment_id"

    def list(self, q=None, limit=None, offset=None, sort_by=None, sort_order=None):
        """List shipments with optional filters.

        Args:
            q: Search query string (optional)
            limit: Maximum number of results (optional)
            offset: Result offset (optional)
            sort_by: Field name to sort by (optional)
            sort_order: Sort direction: 'asc' or 'desc' (optional)

        Returns:
            List of shipment dicts
        """
        params = {}
        if q is not None:
            params["q"] = q
        if offset is not None:
            params["offset"] = offset
        _apply_limit(params, limit)
        if sort_by is not None:
            params["sort_by"] = sort_by
        if sort_order is not None:
            params["sort_order"] = sort_order
        return self._http.get(self._base_path, params=params)

    def get(self, shipment_id):
        """Get a single shipment by ID.

        Args:
            shipment_id: Shipment ID

        Returns:
            Shipment dict
        """
        _validate_id(shipment_id, "shipment_id")
        return self._http.get(f"{self._base_path}/{shipment_id}")

    def create(self, **kwargs):
        """Create a new shipment (always as draft).

        Args:
            **kwargs: Shipment fields

        Returns:
            Created shipment dict

        Raises:
            DraftOnlyError: If is_draft=False is passed
        """
        if kwargs.get("is_draft") is False:
            raise DraftOnlyError("Cannot create a non-draft entity via borgprime_client.")
        kwargs["is_draft"] = True
        return self._http.post(self._base_path, json=kwargs)

    def update(self, shipment_id, **kwargs):
        """Update a shipment (only if draft).

        Args:
            shipment_id: Shipment ID
            **kwargs: Fields to update

        Returns:
            Updated shipment dict

        Raises:
            DraftOnlyError: If shipment is not a draft
        """
        self._assert_draft(shipment_id)
        return self._http.put(f"{self._base_path}/{shipment_id}", json=kwargs)

    def delete(self, shipment_id):
        """Delete a shipment (only if draft).

        Args:
            shipment_id: Shipment ID

        Returns:
            Response dict

        Raises:
            DraftOnlyError: If shipment is not a draft
        """
        self._assert_draft(shipment_id)
        return self._http.delete(f"{self._base_path}/{shipment_id}")

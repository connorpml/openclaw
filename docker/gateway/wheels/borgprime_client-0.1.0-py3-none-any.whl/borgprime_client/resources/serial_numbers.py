"""Serial numbers resource for BorgPrime API."""

from ..exceptions import DraftOnlyError
from ._base import DraftResource, _apply_limit, _validate_id


class SerialNumbersResource(DraftResource):
    """Resource for managing serial numbers."""

    _base_path = "/api/serial-numbers"
    _id_kwarg = "serial_number_id"

    def list(self, q=None, limit=None, offset=None, sort_by=None, sort_order=None):
        """List serial numbers with optional filters.

        Args:
            q: Search query string (optional)
            limit: Maximum number of results (optional)
            offset: Result offset (optional)
            sort_by: Field name to sort by (optional)
            sort_order: Sort direction: 'asc' or 'desc' (optional)

        Returns:
            List of serial number dicts
        """
        params = {}
        if q is not None:
            params["q"] = q
        if offset is not None:
            params["offset"] = offset
        _apply_limit(params, limit)
        if sort_by is not None:
            params["sort_by"] = sort_by
        if sort_order is not None:
            params["sort_order"] = sort_order
        return self._http.get(self._base_path, params=params)

    def get(self, serial_number_id):
        """Get a single serial number by ID.

        Args:
            serial_number_id: Serial number ID

        Returns:
            Serial number dict
        """
        _validate_id(serial_number_id, "serial_number_id")
        return self._http.get(f"{self._base_path}/{serial_number_id}")

    def create(self, **kwargs):
        """Create a new serial number (always as draft).

        Args:
            **kwargs: Serial number fields

        Returns:
            Created serial number dict

        Raises:
            DraftOnlyError: If is_draft=False is passed
        """
        if kwargs.get("is_draft") is False:
            raise DraftOnlyError("Cannot create a non-draft entity via borgprime_client.")
        kwargs["is_draft"] = True
        return self._http.post(self._base_path, json=kwargs)

    def update(self, serial_number_id, **kwargs):
        """Update a serial number (only if draft).

        Args:
            serial_number_id: Serial number ID
            **kwargs: Fields to update

        Returns:
            Updated serial number dict

        Raises:
            DraftOnlyError: If serial number is not a draft
        """
        self._assert_draft(serial_number_id)
        return self._http.put(f"{self._base_path}/{serial_number_id}", json=kwargs)

    def delete(self, serial_number_id):
        """Delete a serial number (only if draft).

        Args:
            serial_number_id: Serial number ID

        Returns:
            Response dict

        Raises:
            DraftOnlyError: If serial number is not a draft
        """
        self._assert_draft(serial_number_id)
        return self._http.delete(f"{self._base_path}/{serial_number_id}")

"""Base classes for BorgPrime resources."""

from .._http import DEFAULT_LIST_LIMIT, MAX_LIST_LIMIT
from ..exceptions import DraftOnlyError


_THUMBNAIL_KEYS = {"thumbnail_data", "thumbnail"}


def _strip_thumbnails(data):
    """Recursively remove thumbnail fields from API response data.

    Strips thumbnail_data and thumbnail keys from dicts. For list values
    inside a dict (e.g., children/parents on a part), recurses into them.
    """
    if isinstance(data, list):
        return [_strip_thumbnails(item) for item in data]
    if isinstance(data, dict):
        result = {}
        for k, v in data.items():
            if k in _THUMBNAIL_KEYS:
                continue
            if isinstance(v, list):
                result[k] = _strip_thumbnails(v)
            else:
                result[k] = v
        return result
    return data


def _apply_limit(params: dict, limit) -> dict:
    """Enforce default and maximum limits on list query params.

    If limit is None, DEFAULT_LIST_LIMIT is applied.
    If limit exceeds MAX_LIST_LIMIT, it is clamped to MAX_LIST_LIMIT.
    """
    if limit is None:
        params["limit"] = DEFAULT_LIST_LIMIT
    else:
        params["limit"] = min(int(limit), MAX_LIST_LIMIT)
    return params


def _validate_id(entity_id, name="entity_id"):
    """Raise ValueError if entity_id is not a non-negative integer."""
    if not isinstance(entity_id, int) or isinstance(entity_id, bool):
        raise ValueError(
            f"{name} must be an integer, got {type(entity_id).__name__!r}: {entity_id!r}"
        )
    if entity_id < 0:
        raise ValueError(f"{name} must be a non-negative integer, got {entity_id}")


class BaseResource:
    """Base class for all resources."""

    def __init__(self, http):
        """Initialize resource with HTTP session.

        Args:
            http: _Session instance for making HTTP calls
        """
        self._http = http


class DraftResource(BaseResource):
    """Base class for resources with draft-gated entities.

    Subclasses must set _base_path (e.g., "/api/parts") and _id_kwarg
    (e.g., "part_id") — the kwarg name used by update/delete methods.
    """

    _base_path: str
    _id_kwarg: str = "entity_id"

    def _assert_draft(self, entity_id):
        """Pre-fetch entity and verify it is a draft.

        Raises:
            ValueError: If entity_id is not a valid integer
            DraftOnlyError: If entity is not a draft
        """
        _validate_id(entity_id)
        entity = self._http.get(f"{self._base_path}/{entity_id}")
        if not entity.get("is_draft", False):
            raise DraftOnlyError(f"Entity {entity_id} is not a draft; refusing to mutate.")

    def update_as_draft(self, **kwargs):
        """Update an entity, routing to draft-update mode for non-draft entities.

        If the entity is already a draft, sends a normal PUT.
        If the entity is live (not draft), sends PUT ?draft=true which stores
        a pre_update_snapshot on the backend — the same behavior as the UI's
        "Save as Draft" button in edit mode.

        The entity ID is extracted from kwargs using the subclass's _id_kwarg
        (e.g., part_id, ledger_id, order_id, shipment_id).

        Args:
            **kwargs: Must include the entity ID kwarg, plus fields to update

        Returns:
            Updated entity dict
        """
        entity_id = kwargs.pop(self._id_kwarg)
        _validate_id(entity_id)
        entity = self._http.get(f"{self._base_path}/{entity_id}")
        if entity.get("is_draft", False):
            return self._http.put(f"{self._base_path}/{entity_id}", json=kwargs)
        else:
            return self._http.put(
                f"{self._base_path}/{entity_id}",
                json=kwargs,
                params={"draft": "true"},
            )

    def delete_as_draft(self, **kwargs):
        """Delete an entity, routing to draft-delete mode for live entities.

        If the entity is already a draft, sends a normal DELETE (hard-delete).
        If the entity is live, sends DELETE ?draft=true which sets
        pending_delete=true on the backend — the same behavior as the UI's
        "Delete as Draft" action. Live entities are explicitly supported;
        no DraftOnlyError is raised.

        The entity ID is extracted from kwargs using the subclass's _id_kwarg.

        Args:
            **kwargs: Must include exactly the entity ID kwarg

        Returns:
            Response dict (or None on HTTP 204 from a draft hard-delete)
        """
        entity_id = kwargs.pop(self._id_kwarg)
        _validate_id(entity_id)
        entity = self._http.get(f"{self._base_path}/{entity_id}")
        if entity.get("is_draft", False):
            return self._http.delete(f"{self._base_path}/{entity_id}")
        else:
            return self._http.delete(
                f"{self._base_path}/{entity_id}",
                params={"draft": "true"},
            )

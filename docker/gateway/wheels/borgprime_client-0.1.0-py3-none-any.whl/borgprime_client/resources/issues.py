"""Issues resource for BorgPrime API."""

from ._base import BaseResource


class IssuesResource(BaseResource):
    """Resource for reading and managing issue dismissals.

    Issues are read-only aggregations — no draft gating needed.
    Dismiss/restore operations mutate the dismissed_issues table
    but are always allowed.
    """

    _base_path = "/api/issues"

    def list(self, entity_type=None, limit=25):
        """Get active (non-dismissed) entities with issues.

        Args:
            entity_type: Optional filter — only return entities of this type
                         (e.g., "ledger", "part", "sales_order"). When supplied,
                         counts and issue_counts are also scoped to the filtered
                         entity set so the three numbers tell one coherent story.
            limit: Max entities to return (default 25). Counts reflect the
                   pre-limit entity set (scoped by entity_type when applied).

        Returns:
            Dict with entities (filtered/capped), counts, issue_counts,
            and dismissed_count.
        """
        result = self._http.get(self._base_path)
        entities = result.get("entities", [])
        if entity_type:
            entities = [e for e in entities if e.get("entity_type") == entity_type]
            result["counts"] = {entity_type: len(entities), "total": len(entities)}
            issue_counts = {}
            for ent in entities:
                for issue in ent.get("issues", []):
                    itype = issue.get("issue_type")
                    if itype:
                        issue_counts[itype] = issue_counts.get(itype, 0) + 1
            result["issue_counts"] = issue_counts
        if limit is not None:
            entities = entities[:int(limit)]
        result["entities"] = entities
        return result

    def dismissed(self):
        """Get all dismissed issues.

        Returns:
            List of dismissed issue records.
        """
        return self._http.get(f"{self._base_path}/dismissed")

    def dismiss(self, issue_type, entity_id):
        """Dismiss an issue so it no longer appears in list().

        Args:
            issue_type: Type of issue (e.g., "draft", "overdue")
            entity_id: ID of the entity to dismiss

        Returns:
            Confirmation dict.
        """
        return self._http.post(
            f"{self._base_path}/dismiss",
            json={"issue_type": issue_type, "entity_id": entity_id},
        )

    def restore(self, issue_type, entity_id):
        """Restore a previously dismissed issue.

        Args:
            issue_type: Type of issue
            entity_id: ID of the entity to restore

        Returns:
            Confirmation dict.
        """
        return self._http.delete(
            f"{self._base_path}/dismiss",
            json={"issue_type": issue_type, "entity_id": entity_id},
        )

    def clear_all_dismissed(self):
        """Clear all dismissals.

        Returns:
            Confirmation dict or None.
        """
        return self._http.delete(f"{self._base_path}/dismissed")

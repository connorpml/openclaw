"""Businesses resource for BorgPrime API."""

from ._base import BaseResource, _apply_limit, _validate_id


class BusinessesResource(BaseResource):
    """Resource for managing businesses (ungated)."""

    _base_path = "/api/businesses"

    def list(self, q=None, relationship=None, limit=None, sort_by=None, sort_order=None):
        """List businesses with optional filters.

        Args:
            q: Search query string (optional)
            relationship: Filter by relationship type — CUSTOMER, VENDOR, or BOTH (optional)
            limit: Max results (default 100, max 500)
            sort_by: Field name to sort by (optional)
            sort_order: Sort direction: 'asc' or 'desc' (optional)

        Returns:
            List of business dicts
        """
        params = {}
        if q is not None:
            params["q"] = q
        if relationship is not None:
            params["relationship"] = relationship
        _apply_limit(params, limit)
        if sort_by is not None:
            params["sort_by"] = sort_by
        if sort_order is not None:
            params["sort_order"] = sort_order
        return self._http.get(self._base_path, params=params)

    def get(self, business_id):
        """Get a single business by ID.

        Args:
            business_id: Business ID

        Returns:
            Business dict
        """
        _validate_id(business_id, "business_id")
        return self._http.get(f"{self._base_path}/{business_id}")

    def create(self, **kwargs):
        """Create a new business.

        Args:
            **kwargs: Business fields

        Returns:
            Created business dict
        """
        return self._http.post(self._base_path, json=kwargs)

    def update(self, business_id, **kwargs):
        """Update a business.

        Args:
            business_id: Business ID
            **kwargs: Fields to update

        Returns:
            Updated business dict
        """
        return self._http.put(f"{self._base_path}/{business_id}", json=kwargs)

    def delete(self, business_id):
        """Delete a business.

        Args:
            business_id: Business ID

        Returns:
            Response dict
        """
        return self._http.delete(f"{self._base_path}/{business_id}")

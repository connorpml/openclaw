"""Resources package for borgprime_client."""

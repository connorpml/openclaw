"""Parts resource for BorgPrime API."""

from ..exceptions import DraftOnlyError
from ._base import DraftResource, _apply_limit, _strip_thumbnails, _validate_id


class PartsResource(DraftResource):
    """Resource for managing parts."""

    _base_path = "/api/parts"
    _id_kwarg = "part_id"

    def list(self, q=None, limit=None, offset=None, sort_by=None, sort_order=None, mfg_part_number=None):
        """List parts with optional filters.

        Args:
            q: Search query string (optional)
            limit: Maximum number of results (optional)
            offset: Result offset (optional)
            sort_by: Field name to sort by (optional)
            sort_order: Sort direction: 'asc' or 'desc' (optional)
            mfg_part_number: Filter by manufacturer part number (optional)

        Returns:
            List of part dicts
        """
        params = {}
        if q is not None:
            params["q"] = q
        if offset is not None:
            params["offset"] = offset
        _apply_limit(params, limit)
        if sort_by is not None:
            params["sort_by"] = sort_by
        if sort_order is not None:
            params["sort_order"] = sort_order
        if mfg_part_number is not None:
            params["mfg_part_number"] = mfg_part_number
        result = self._http.get(self._base_path, params=params)
        if not self._http.include_thumbnails:
            result = _strip_thumbnails(result)
        return result

    def get(self, part_id):
        """Get a single part by ID.

        Args:
            part_id: Part ID

        Returns:
            Part dict
        """
        _validate_id(part_id, "part_id")
        result = self._http.get(f"{self._base_path}/{part_id}")
        if not self._http.include_thumbnails:
            result = _strip_thumbnails(result)
        return result

    def search(self, q=None, limit=None, mfg_part_number=None, sort_by=None, sort_order=None):
        """Search parts by query and/or manufacturer part number.

        Args:
            q: Search query string (optional)
            limit: Maximum number of results (optional)
            mfg_part_number: Filter by manufacturer part number (optional)
            sort_by: Field name to sort by (optional; forwarded to backend)
            sort_order: Sort direction 'asc' or 'desc' (optional; forwarded to backend)

        Returns:
            List of part dicts
        """
        params = {}
        if q is not None:
            params["q"] = q
        if limit is not None:
            params["limit"] = limit
        if mfg_part_number is not None:
            params["mfg_part_number"] = mfg_part_number
        if sort_by is not None:
            params["sort_by"] = sort_by
        if sort_order is not None:
            params["sort_order"] = sort_order
        result = self._http.get(f"{self._base_path}/search", params=params)
        if not self._http.include_thumbnails:
            result = _strip_thumbnails(result)
        return result

    def create(self, **kwargs):
        """Create a new part (always as draft).

        Args:
            **kwargs: Part fields (e.g., name, prefix, description)

        Returns:
            Created part dict

        Raises:
            DraftOnlyError: If is_draft=False is passed
        """
        if kwargs.get("is_draft") is False:
            raise DraftOnlyError("Cannot create a non-draft entity via borgprime_client.")
        kwargs["is_draft"] = True
        return self._http.post(self._base_path, json=kwargs)

    def update(self, part_id, **kwargs):
        """Update a part (only if draft).

        Args:
            part_id: Part ID
            **kwargs: Fields to update

        Returns:
            Updated part dict

        Raises:
            DraftOnlyError: If part is not a draft
        """
        self._assert_draft(part_id)
        return self._http.put(f"{self._base_path}/{part_id}", json=kwargs)

    def delete(self, part_id):
        """Delete a part (only if draft).

        Args:
            part_id: Part ID

        Returns:
            Response dict

        Raises:
            DraftOnlyError: If part is not a draft
        """
        self._assert_draft(part_id)
        return self._http.delete(f"{self._base_path}/{part_id}")

    def get_relationships(self, part_id):
        """Get part relationships (BOM children).

        Args:
            part_id: Part ID

        Returns:
            List of child relationship dicts
        """
        result = self._http.get(f"{self._base_path}/{part_id}/relationships")
        if not self._http.include_thumbnails:
            result = _strip_thumbnails(result)
        return result

    def get_parents(self, part_id):
        """Get parent assemblies that contain this part.

        Args:
            part_id: Part ID

        Returns:
            List of parent relationship dicts
        """
        result = self._http.get(f"{self._base_path}/{part_id}/parents")
        if not self._http.include_thumbnails:
            result = _strip_thumbnails(result)
        return result

    def add_relationship(self, parent_id, child_id, quantity=1):
        """Add a child part to a parent's BOM.

        Args:
            parent_id: Parent part ID
            child_id: Child part ID
            quantity: Quantity in BOM (default: 1)

        Returns:
            Response dict
        """
        body = {"child_id": child_id, "quantity": quantity}
        return self._http.post(f"{self._base_path}/{parent_id}/relationships", json=body)

    def remove_relationship(self, parent_id, child_id):
        """Remove a child part from a parent's BOM.

        Args:
            parent_id: Parent part ID
            child_id: Child part ID

        Returns:
            Response dict
        """
        return self._http.delete(f"{self._base_path}/{parent_id}/relationships/{child_id}")

    def get_procedures(self, part_id):
        """Get manufacturing procedures for a part.

        Args:
            part_id: Part ID

        Returns:
            List of procedure dicts
        """
        return self._http.get(f"{self._base_path}/{part_id}/procedures")

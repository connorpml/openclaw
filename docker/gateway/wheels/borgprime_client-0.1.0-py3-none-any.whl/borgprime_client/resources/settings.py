"""Settings resource for BorgPrime API."""

from ._base import BaseResource


class SettingsResource(BaseResource):
    """Resource for reading settings (read-only)."""

    _base_path = "/api/settings"

    def get(self, key):
        """Get a setting value by key.

        Args:
            key: Setting key

        Returns:
            Setting value dict
        """
        return self._http.get(f"{self._base_path}/{key}")

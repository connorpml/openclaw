"""HTTP session wrapper for BorgPrime API."""

import requests
from .exceptions import BorgPrimeError, NotFoundError, ServerError, TimeoutError, ConnectionError

# Applied automatically when no limit is provided on list() calls.
DEFAULT_LIST_LIMIT = 100
# Hard ceiling — caller-supplied limits above this are clamped silently.
MAX_LIST_LIMIT = 500


class _Session:
    """Thin wrapper around requests.Session for BorgPrime API calls."""

    def __init__(self, base_url: str, timeout: int = 10, include_thumbnails: bool = False):
        """Initialize session with base URL and timeout.

        Args:
            base_url: Base URL of BorgPrime API (trailing slash will be stripped)
            timeout: Request timeout in seconds
            include_thumbnails: If False (default), strip thumbnail_data fields from responses
        """
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.include_thumbnails = include_thumbnails
        self._session = requests.Session()

    def _raise_for_status(self, response):
        """Raise appropriate exception based on HTTP status code."""
        if response.status_code == 404:
            raise NotFoundError(f"Not found: {response.status_code}")
        elif response.status_code >= 500:
            raise ServerError(f"Server error: {response.status_code}")
        elif response.status_code >= 400:
            # Extract error message from JSON body if available
            try:
                body = response.json()
                msg = body.get("error", response.text)
            except Exception:
                msg = response.text
            raise BorgPrimeError(f"Bad request ({response.status_code}): {msg}")

    def _wrap_request(self, fn):
        """Execute fn(), converting requests exceptions to BorgPrimeError subclasses."""
        try:
            return fn()
        except requests.exceptions.Timeout:
            raise TimeoutError(
                "Request timed out. Use a narrower filter (e.g. part_id=, type=, search=) "
                "or pass a smaller limit=, or increase BorgPrimeClient(timeout=...)."
            )
        except requests.exceptions.ConnectionError:
            raise ConnectionError(
                f"Could not connect to BorgPrime at {self.base_url}. "
                "Is the backend running?"
            )

    def _process(self, data):
        """Strip nulls (and optionally thumbnails) from a parsed JSON response.

        Recursively removes None values from dicts and applies the same to
        list items. This keeps tool results concise for AI agent consumption.
        """
        if isinstance(data, list):
            return [self._process(item) for item in data]
        if isinstance(data, dict):
            result = {k: self._process(v) for k, v in data.items() if v is not None}
            if not self.include_thumbnails:
                result.pop("thumbnail_data", None)
                result.pop("thumbnail", None)
            return result
        return data

    def get(self, path, params=None):
        """Perform GET request.

        Args:
            path: API path (e.g., "/api/parts")
            params: Query parameters dict (optional)

        Returns:
            Parsed JSON response (nulls stripped)
        """
        url = f"{self.base_url}{path}"
        response = self._wrap_request(lambda: self._session.get(url, params=params, timeout=self.timeout))
        self._raise_for_status(response)
        return self._process(response.json())

    def post(self, path, json=None):
        """Perform POST request.

        Args:
            path: API path (e.g., "/api/parts")
            json: Request body dict (optional)

        Returns:
            Parsed JSON response (nulls stripped)
        """
        url = f"{self.base_url}{path}"
        response = self._wrap_request(lambda: self._session.post(url, json=json, timeout=self.timeout))
        self._raise_for_status(response)
        return self._process(response.json())

    def put(self, path, json=None, params=None):
        """Perform PUT request.

        Args:
            path: API path (e.g., "/api/parts/1")
            json: Request body dict (optional)
            params: Query parameters dict (optional)

        Returns:
            Parsed JSON response (nulls stripped)
        """
        url = f"{self.base_url}{path}"
        response = self._wrap_request(lambda: self._session.put(url, json=json, params=params, timeout=self.timeout))
        self._raise_for_status(response)
        return self._process(response.json())

    def delete(self, path, json=None, params=None):
        """Perform DELETE request.

        Args:
            path: API path (e.g., "/api/parts/1")
            json: Request body dict (optional)
            params: Query parameters dict (optional, e.g. {"draft": "true"})

        Returns:
            Parsed JSON response (nulls stripped)
        """
        url = f"{self.base_url}{path}"
        response = self._wrap_request(lambda: self._session.delete(url, json=json, params=params, timeout=self.timeout))
        self._raise_for_status(response)
        if response.status_code == 204 or not response.content:
            return None
        return self._process(response.json())

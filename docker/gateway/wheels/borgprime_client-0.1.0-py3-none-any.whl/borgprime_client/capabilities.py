"""
Agent capability routing table.

Single source of truth for what the AI agent can and cannot do.
Each entity declares permission flags, visible fields, and tool definitions.
Flip a boolean to grant or revoke a capability. If an entity has tool entries
for that action, they become live automatically — no wiring needed elsewhere.
Entities not listed here have zero agent access.
"""

import json
import re


# Entities whose canonical identifier is a fixed prefix + integer id.
# Used by _resolve_params() as bare-integer fallback targets.
_ENTITY_PREFIXES = {
    "manufacturing_orders": "MO",
    "purchase_orders": "PO",
    "sales_orders": "SO",
}


AGENT_CAPABILITIES = {
    "parts": {
        "read":         True,
        "create_draft": True,
        "update_draft": True,
        "delete_draft": True,
        "visible_fields": {"part_number", "name", "description", "mfg_part_number", "is_draft", "current_stock", "quantity", "primary_vendor_name", "secondary_vendor_name", "standard_price_usd", "quantity_per_pack", "default_lead_time_days"},
        "tools": [
            {
                "action": "read",
                "name": "search_parts",
                "description": "Search for parts by name or part number, optionally filtered by manufacturer part number",
                "method": "search",
                "params": {
                    "query": {"kwarg": "q", "type": "string", "description": "Search query (part name or number)"},
                    "mfg_part_number": {"kwarg": "mfg_part_number", "type": "string", "description": "Filter by manufacturer part number (vendor/OEM catalog number)"},
                    "limit": {"kwarg": "limit", "type": "integer", "description": "Maximum number of results to return (default 20)", "default": 20},
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                    "sort_by": {"kwarg": "sort_by", "type": "string", "description": "Field name to sort by (must be in visible_fields for this entity)"},
                    "sort_order": {"kwarg": "sort_order", "type": "string", "description": "Sort direction: 'asc' (default) or 'desc'"},
                },
                "required": [],
            },
            {
                "action": "read",
                "name": "get_part",
                "description": "Get detailed information about a single part by its part number",
                "method": "get",
                "params": {
                    "part_number": {"kwarg": "part_id", "type": "string", "description": "The part number of the part to retrieve (e.g. 'SEN-1883'); resolved to integer ID", "resolve": {"entity": "parts", "search_kwarg": "q", "match_field": "part_number", "case_sensitive": True}},
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                },
                "required": ["part_number"],
            },
            {
                "action": "read",
                "name": "get_part_children",
                "description": "Get the child subcomponents (BOM) of a part — lists each child part with its quantity in the assembly.",
                "method": "get_relationships",
                "params": {
                    "part_number": {"kwarg": "part_id", "type": "string", "description": "The part number to get children for (e.g. 'SEN-1883'); resolved to integer ID", "resolve": {"entity": "parts", "search_kwarg": "q", "match_field": "part_number", "case_sensitive": True}},
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                },
                "required": ["part_number"],
            },
            {
                "action": "read",
                "name": "get_part_parents",
                "description": "Get the parent assemblies that contain this part — lists each parent part with the quantity of this part used.",
                "method": "get_parents",
                "params": {
                    "part_number": {"kwarg": "part_id", "type": "string", "description": "The part number to get parent assemblies for (e.g. 'SEN-1883'); resolved to integer ID", "resolve": {"entity": "parts", "search_kwarg": "q", "match_field": "part_number", "case_sensitive": True}},
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                },
                "required": ["part_number"],
            },
            {
                "action": "create_draft",
                "name": "create_draft_part",
                "description": "Create a DRAFT part. Draft parts are placeholders and must be confirmed by a user before becoming permanent.",
                "method": "create",
                "params": {
                    "name":        {"kwarg": "name", "type": "string", "description": "Name of the part"},
                    "prefix":      {"kwarg": "prefix", "type": "string", "description": "Prefix for the part number (e.g., 'FAB', 'WID')"},
                    "description": {"kwarg": "description", "type": "string", "description": "Optional description of the part"},
                    "mfg_part_number": {"kwarg": "mfg_part_number", "type": "string", "description": "Manufacturer/OEM catalog number for this part (distinct from the internal BorgPrime part number)"},
                },
                "required": ["name", "prefix"],
            },
            {
                "action": "update_draft",
                "name": "update_draft_part",
                "description": "Update a part as a DRAFT edit. Draft parts are modified directly; live parts get a pending draft update that must be approved or rejected.",
                "method": "update_as_draft",
                "params": {
                    "part_number": {"kwarg": "part_id", "type": "string", "description": "The part number of the draft part to update (e.g. 'SEN-1883'); resolved to integer ID", "resolve": {"entity": "parts", "search_kwarg": "q", "match_field": "part_number", "case_sensitive": True}},
                    "name":        {"kwarg": "name", "type": "string", "description": "New name for the part"},
                    "description": {"kwarg": "description", "type": "string", "description": "New description for the part"},
                    "mfg_part_number": {"kwarg": "mfg_part_number", "type": "string", "description": "Manufacturer/OEM catalog number for this part (distinct from the internal BorgPrime part number)"},
                    "standard_price_usd": {"kwarg": "standard_price_usd", "type": "number", "description": "Standard unit price in USD"},
                },
                "required": ["part_number"],
            },
            {
                "action": "delete_draft",
                "name": "delete_draft_part",
                "description": "Delete a part. Drafts are hard-deleted; live parts are soft-deleted (pending_delete=true) for review.",
                "method": "delete_as_draft",
                "params": {
                    "part_number": {"kwarg": "part_id", "type": "string", "description": "The part number of the draft part to delete (e.g. 'SEN-1883'); resolved to integer ID", "resolve": {"entity": "parts", "search_kwarg": "q", "match_field": "part_number", "case_sensitive": True}},
                },
                "required": ["part_number"],
            },
        ],
    },
    "ledger": {
        "read":         True,
        "create_draft": True,
        "update_draft": True,
        "delete_draft": True,
        "visible_fields": {"ledger_number", "type", "quantity", "status", "start_date", "end_date", "part_number", "notes", "tags", "qty_on_hand", "price", "business_name"},
        "tools": [
            {
                "action": "read",
                "name": "get_ledger_entry",
                "description": "Get a single ledger entry by its ledger number (e.g. 'MK-42'). Use this to fetch a specific entry (including child TAKE entries from BOM explosions that may not appear in list_ledger results).",
                "method": "get",
                "params": {
                    "ledger_number": {"kwarg": "ledger_id", "type": "string", "description": "The ledger number of the entry to retrieve (e.g. 'MK-42'); resolved to integer ID", "resolve": {"entity": "ledger", "search_kwarg": None, "match_field": "ledger_number", "case_sensitive": False}},
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                },
                "required": ["ledger_number"],
            },
            {
                "action": "read",
                "name": "list_ledger",
                "description": "List ledger entries (inventory transactions) with optional filters",
                "method": "list",
                "params": {
                    "part_number": {"kwarg": "part_id", "type": "string", "description": "Filter by part number (e.g. 'SEN-1883'); resolved to integer ID", "resolve": {"entity": "parts", "search_kwarg": "q", "match_field": "part_number", "case_sensitive": True}},
                    "type":    {"kwarg": "type", "type": "string", "description": "Filter by entry type (MAKE, TAKE, RECEIVE, SHIP, ADJUST)"},
                    "limit":   {"kwarg": "limit", "type": "integer", "description": "Maximum number of results (default 20)", "default": 20},
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                    "sort_by": {"kwarg": "sort_by", "type": "string", "description": "Field name to sort by (must be in visible_fields for this entity)"},
                    "sort_order": {"kwarg": "sort_order", "type": "string", "description": "Sort direction: 'asc' (default) or 'desc'"},
                },
                "required": [],
            },
            {
                "action": "create_draft",
                "name": "create_draft_ledger_entry",
                "description": "Create a DRAFT ledger entry (inventory transaction). Draft entries must be confirmed before becoming permanent. Tags are required — call list_tags first to pick relevant tags, or supply new tag names to auto-create them.",
                "method": "create",
                "response_key": "created",
                "params": {
                    "part_number": {"kwarg": "part_id", "type": "string", "description": "The part number of the part this entry is for (e.g. 'SEN-1883'); resolved to integer ID", "resolve": {"entity": "parts", "search_kwarg": "q", "match_field": "part_number", "case_sensitive": True}},
                    "quantity":   {"kwarg": "quantity", "type": "number", "description": "The quantity to add or remove (supports decimals, e.g. 0.5)"},
                    "type":       {"kwarg": "type", "type": "string", "description": "Entry type: MAKE, TAKE, RECEIVE, SHIP, or ADJUST"},
                    "tag_names":  {"kwarg": "new_tags", "type": "array", "items": {"type": "string"}, "description": "Tag names to attach to this entry. Existing tags are reused (case-insensitive); new names are auto-created. At least one tag is required."},
                    "notes":      {"kwarg": "notes", "type": "string", "description": "Optional notes about the entry"},
                    "start_date": {"kwarg": "start_date", "type": "string", "description": "Start date in YYYY-MM-DD format (optional)"},
                    "end_date":   {"kwarg": "end_date", "type": "string", "description": "End date in YYYY-MM-DD format (required)"},
                    "unit_price": {"kwarg": "price", "type": "number", "description": "Unit price for this entry (e.g. the line price on a customer PO)"},
                },
                "required": ["part_number", "quantity", "type", "end_date", "tag_names"],
            },
            {
                "action": "update_draft",
                "name": "update_draft_ledger_entry",
                "description": "Update a ledger entry as a DRAFT edit. Draft entries are modified directly; live entries get a pending draft update that must be approved or rejected.",
                "method": "update_as_draft",
                "response_key": "updated",
                "params": {
                    "ledger_number": {"kwarg": "ledger_id", "type": "string", "description": "The ledger number of the entry to update (e.g. 'MK-42'); resolved to integer ID", "resolve": {"entity": "ledger", "search_kwarg": None, "match_field": "ledger_number", "case_sensitive": False}},
                    "quantity":   {"kwarg": "quantity", "type": "number", "description": "New quantity (supports decimals, e.g. 0.5)"},
                    "type":       {"kwarg": "type", "type": "string", "description": "New entry type: MAKE, TAKE, RECEIVE, SHIP, or ADJUST"},
                    "tag_names":  {"kwarg": "new_tags", "type": "array", "items": {"type": "string"}, "description": "Overwrites all tags on this entry with the given names. Existing tags are reused (case-insensitive); new names are auto-created. Pass an empty list to remove all tags."},
                    "notes":      {"kwarg": "notes", "type": "string", "description": "New notes"},
                    "start_date": {"kwarg": "start_date", "type": "string", "description": "New start date in YYYY-MM-DD format"},
                    "end_date":   {"kwarg": "end_date", "type": "string", "description": "New end date in YYYY-MM-DD format"},
                    "status":     {"kwarg": "status", "type": "string", "description": "New status: PENDING, STARTED, or FINISHED"},
                    "unit_price": {"kwarg": "price", "type": "number", "description": "Unit price for this entry (e.g. the line price on a customer PO)"},
                },
                "required": ["ledger_number"],
            },
            {
                "action": "delete_draft",
                "name": "delete_draft_ledger_entry",
                "description": "Delete a ledger entry. Drafts are hard-deleted; live entries are soft-deleted (pending_delete=true) for review.",
                "method": "delete_as_draft",
                "params": {
                    "ledger_number": {"kwarg": "ledger_id", "type": "string", "description": "The ledger number of the entry to delete (e.g. 'MK-5'); resolved to integer ID", "resolve": {"entity": "ledger", "search_kwarg": None, "match_field": "ledger_number", "case_sensitive": False}},
                },
                "required": ["ledger_number"],
            },
            {
                "action": "update_draft",
                "name": "batch_update_draft_ledger_entries",
                "description": "Stage the same field update on multiple ledger entries in one request (e.g. mark 8 TAKE entries FINISHED). Only live entries are eligible — draft entries (is_draft=True) are rejected. Each entry gets a pre_update_snapshot; staged changes can be approved or rejected individually. cascade_children is not supported in batch mode.",
                "method": "bulk_update_as_draft",
                "params": {
                    "ledger_ids":  {"kwarg": "ledger_ids", "type": "array", "items": {"type": "integer"}, "description": "List of integer ledger entry IDs to update"},
                    "status":      {"kwarg": "status", "type": "string", "description": "New status: PENDING, STARTED, or FINISHED"},
                    "quantity":    {"kwarg": "quantity", "type": "number", "description": "New quantity (supports decimals, e.g. 0.5)"},
                    "start_date":  {"kwarg": "start_date", "type": "string", "description": "New start date in YYYY-MM-DD format"},
                    "end_date":    {"kwarg": "end_date", "type": "string", "description": "New end date in YYYY-MM-DD format"},
                    "notes":       {"kwarg": "notes", "type": "string", "description": "New notes to apply to all entries"},
                    "unit_price":  {"kwarg": "price", "type": "number", "description": "New unit price for all entries"},
                },
                "required": ["ledger_ids"],
            },
            {
                "action": "read",
                "name": "get_purchase_order_ledger_entries",
                "description": "List all ledger entries linked to a specific purchase order (typically RECEIVE entries)",
                "method": "list",
                "params": {
                    "po_number": {"kwarg": "purchase_order_id", "type": "string", "description": "PO number (e.g. PO-00012)", "resolve": {"entity": "purchase_orders", "search_kwarg": "q", "match_field": "po_number", "case_sensitive": True}},
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                },
                "required": ["po_number"],
            },
            {
                "action": "read",
                "name": "get_sales_order_ledger_entries",
                "description": "List all ledger entries linked to a specific sales order (typically SHIP entries)",
                "method": "list",
                "params": {
                    "so_number": {"kwarg": "sales_order_id", "type": "string", "description": "SO number (e.g. SO-00005)", "resolve": {"entity": "sales_orders", "search_kwarg": "q", "match_field": "so_number", "case_sensitive": True}},
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                },
                "required": ["so_number"],
            },
            {
                "action": "read",
                "name": "get_manufacturing_order_ledger_entries",
                "description": "List all ledger entries linked to a specific manufacturing order (typically MAKE entries)",
                "method": "list",
                "params": {
                    "mo_number": {"kwarg": "manufacturing_order_id", "type": "string", "description": "MO number (e.g. MO-00003)", "resolve": {"entity": "manufacturing_orders", "search_kwarg": "q", "match_field": "mo_number", "case_sensitive": True}},
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                },
                "required": ["mo_number"],
            },
            {
                "action": "read",
                "name": "get_shipment_ledger_entries",
                "description": "List all ledger entries linked to a specific shipment (SHIP entries)",
                "method": "list",
                "params": {
                    "shipment_number": {"kwarg": "shipment_id", "type": "string", "description": "Shipment number (e.g. SHP-132)", "resolve": {"entity": "shipments", "search_kwarg": "q", "match_field": "shipment_number", "case_sensitive": True}},
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                },
                "required": ["shipment_number"],
            },
        ],
    },
    "purchase_orders": {
        "read":         True,
        "create_draft": True,
        "update_draft": True,
        "delete_draft": True,
        "visible_fields": {"po_number", "description", "po_due_date", "po_date", "total_price", "is_draft", "business_id", "status", "vendor_billing_address", "ship_to_address"},
        "tools": [
            {
                "action": "read",
                "name": "list_purchase_orders",
                "description": "List all purchase orders",
                "method": "list",
                "params": {
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                    "sort_by": {"kwarg": "sort_by", "type": "string", "description": "Field name to sort by (must be in visible_fields for this entity)"},
                    "sort_order": {"kwarg": "sort_order", "type": "string", "description": "Sort direction: 'asc' (default) or 'desc'"},
                    "limit": {"kwarg": "limit", "type": "integer", "description": "Maximum number of results (default 20)", "default": 20},
                },
                "required": [],
            },
            {
                "action": "create_draft",
                "name": "create_draft_purchase_order",
                "description": "Create a DRAFT purchase order. Draft orders must be confirmed before becoming permanent.",
                "method": "create",
                "params": {
                    "description":           {"kwarg": "description", "type": "string", "description": "Description of the purchase order"},
                    "business_name":         {"kwarg": "business_id", "type": "string", "description": "Optional vendor/business name", "resolve": {"entity": "businesses", "search_kwarg": "q", "match_field": "name", "case_sensitive": False}},
                    "po_date":               {"kwarg": "po_date", "type": "string", "description": "Order date in YYYY-MM-DD format (defaults to today)"},
                    "po_due_date":           {"kwarg": "po_due_date", "type": "string", "description": "Due date in YYYY-MM-DD format (defaults to po_date)"},
                    "comments":              {"kwarg": "comments", "type": "string", "description": "Optional comments"},
                    "vendor_billing_address": {"kwarg": "vendor_billing_address", "type": "string", "description": "Vendor billing address (defaults to business billing address if omitted)"},
                    "ship_to_address":       {"kwarg": "ship_to_address", "type": "string", "description": "Ship to address (defaults to company address if omitted)"},
                    "ledger_entry_ids":      {"kwarg": "ledger_entry_ids", "type": "array", "items": {"type": "string"}, "description": "List of RECEIVE ledger entries to link to this order (accepts ledger_number strings like 'RC-6892' or raw integer IDs)", "resolve": {"entity": "ledger", "search_kwarg": "search", "match_field": "ledger_number", "case_sensitive": False, "per_element": True, "passthrough_int": True}},
                },
                "required": ["business_name"],
            },
            {
                "action": "update_draft",
                "name": "update_draft_purchase_order",
                "description": "Update a purchase order as a DRAFT edit. Draft orders are modified directly; live orders get a pending draft update that must be approved or rejected.",
                "method": "update_as_draft",
                "params": {
                    "po_number":              {"kwarg": "order_id", "type": "string", "description": "The PO number of the draft purchase order to update", "resolve": {"entity": "purchase_orders", "search_kwarg": "q", "match_field": "po_number", "case_sensitive": True}},
                    "description":            {"kwarg": "description", "type": "string", "description": "New description"},
                    "business_name":          {"kwarg": "business_id", "type": "string", "description": "New vendor/business name", "resolve": {"entity": "businesses", "search_kwarg": "q", "match_field": "name", "case_sensitive": False}},
                    "po_date":                {"kwarg": "po_date", "type": "string", "description": "New order date in YYYY-MM-DD format"},
                    "po_due_date":            {"kwarg": "po_due_date", "type": "string", "description": "New due date in YYYY-MM-DD format"},
                    "comments":               {"kwarg": "comments", "type": "string", "description": "New comments"},
                    "vendor_billing_address": {"kwarg": "vendor_billing_address", "type": "string", "description": "New vendor billing address"},
                    "ship_to_address":        {"kwarg": "ship_to_address", "type": "string", "description": "New ship to address"},
                    "add_ledger_entry_ids":    {"kwarg": "add_ledger_entry_ids", "type": "array", "items": {"type": "string"}, "description": "List of RECEIVE ledger entries to link to this order (accepts ledger_number strings like 'RC-6892' or raw integer IDs)", "resolve": {"entity": "ledger", "search_kwarg": "search", "match_field": "ledger_number", "case_sensitive": False, "per_element": True, "passthrough_int": True}},
                    "remove_ledger_entry_ids": {"kwarg": "remove_ledger_entry_ids", "type": "array", "items": {"type": "string"}, "description": "List of RECEIVE ledger entries to unlink from this order (accepts ledger_number strings like 'RC-6892' or raw integer IDs)", "resolve": {"entity": "ledger", "search_kwarg": "search", "match_field": "ledger_number", "case_sensitive": False, "per_element": True, "passthrough_int": True}},
                },
                "required": ["po_number"],
            },
            {
                "action": "delete_draft",
                "name": "delete_draft_purchase_order",
                "description": "Delete a purchase order. Drafts are hard-deleted; live orders are soft-deleted (pending_delete=true) for review.",
                "method": "delete_as_draft",
                "params": {
                    "po_number": {"kwarg": "order_id", "type": "string", "description": "The PO number of the draft purchase order to delete", "resolve": {"entity": "purchase_orders", "search_kwarg": "q", "match_field": "po_number", "case_sensitive": True}},
                },
                "required": ["po_number"],
            },
            {
                "action": "read",
                "name": "get_purchase_order",
                "description": "Get detailed information about a single purchase order by its PO number",
                "method": "get",
                "params": {
                    "po_number": {"kwarg": "order_id", "type": "string", "description": "The PO number of the purchase order to retrieve (e.g. 'PO-630'); resolved to integer ID", "resolve": {"entity": "purchase_orders", "search_kwarg": "q", "match_field": "po_number", "case_sensitive": True}},
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                },
                "required": ["po_number"],
            },
        ],
    },
    "sales_orders": {
        "read":         True,
        "create_draft": True,
        "update_draft": True,
        "delete_draft": True,
        "visible_fields": {"so_number", "description", "customer_due_date", "sales_order_date", "total_price", "is_draft", "business_id", "status", "customer_billing_address", "ship_to_address", "customer_po_number"},
        "tools": [
            {
                "action": "read",
                "name": "list_sales_orders",
                "description": "List all sales orders",
                "method": "list",
                "params": {
                    "query": {"kwarg": "q", "type": "string", "description": "Case-insensitive substring search across so_number, invoice_number, customer_po_number, description, comments, and addresses. Use this to dedup-check a customer PO (e.g. query='P000014658') before intake."},
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                    "sort_by": {"kwarg": "sort_by", "type": "string", "description": "Field name to sort by (must be in visible_fields for this entity)"},
                    "sort_order": {"kwarg": "sort_order", "type": "string", "description": "Sort direction: 'asc' (default) or 'desc'"},
                    "limit": {"kwarg": "limit", "type": "integer", "description": "Maximum number of results (default 20)", "default": 20},
                },
                "required": [],
            },
            {
                "action": "create_draft",
                "name": "create_draft_sales_order",
                "description": "Create a DRAFT sales order. Draft orders must be confirmed before becoming permanent.",
                "method": "create",
                "params": {
                    "description":            {"kwarg": "description", "type": "string", "description": "Description of the sales order"},
                    "business_name":          {"kwarg": "business_id", "type": "string", "description": "Optional customer/business name", "resolve": {"entity": "businesses", "search_kwarg": "q", "match_field": "name", "case_sensitive": False}},
                    "sales_order_date":       {"kwarg": "sales_order_date", "type": "string", "description": "Start date in YYYY-MM-DD format (defaults to today)"},
                    "customer_due_date":      {"kwarg": "customer_due_date", "type": "string", "description": "End/due date in YYYY-MM-DD format (defaults to sales_order_date)"},
                    "customer_po_number":     {"kwarg": "customer_po_number", "type": "string", "description": "Customer's own PO number (e.g. 'P000014658'). Appears on invoices/packing lists and enables dedup via list_sales_orders --query. Do NOT bury this in comments."},
                    "comments":               {"kwarg": "comments", "type": "string", "description": "Optional comments"},
                    "customer_billing_address": {"kwarg": "customer_billing_address", "type": "string", "description": "Customer billing address (defaults to business billing address if omitted)"},
                    "ship_to_address":        {"kwarg": "ship_to_address", "type": "string", "description": "Ship to address (defaults to business shipping address if omitted)"},
                    "ledger_entry_ids":       {"kwarg": "ledger_entry_ids", "type": "array", "items": {"type": "string"}, "description": "List of SHIP ledger entries to link to this order (accepts ledger_number strings like 'SH-6884' or raw integer IDs)", "resolve": {"entity": "ledger", "search_kwarg": "search", "match_field": "ledger_number", "case_sensitive": False, "per_element": True, "passthrough_int": True}},
                },
                "required": ["business_name"],
            },
            {
                "action": "update_draft",
                "name": "update_draft_sales_order",
                "description": "Update a sales order as a DRAFT edit. Draft orders are modified directly; live orders get a pending draft update that must be approved or rejected.",
                "method": "update_as_draft",
                "params": {
                    "so_number":               {"kwarg": "order_id", "type": "string", "description": "The SO number of the draft sales order to update", "resolve": {"entity": "sales_orders", "search_kwarg": "q", "match_field": "so_number", "case_sensitive": True}},
                    "description":             {"kwarg": "description", "type": "string", "description": "New description"},
                    "business_name":           {"kwarg": "business_id", "type": "string", "description": "New customer/business name", "resolve": {"entity": "businesses", "search_kwarg": "q", "match_field": "name", "case_sensitive": False}},
                    "sales_order_date":        {"kwarg": "sales_order_date", "type": "string", "description": "New start date in YYYY-MM-DD format"},
                    "customer_due_date":       {"kwarg": "customer_due_date", "type": "string", "description": "New end/due date in YYYY-MM-DD format"},
                    "customer_po_number":      {"kwarg": "customer_po_number", "type": "string", "description": "Customer's own PO number (e.g. 'P000014658'). Use for corrections; normally set at create time."},
                    "comments":                {"kwarg": "comments", "type": "string", "description": "New comments"},
                    "customer_billing_address": {"kwarg": "customer_billing_address", "type": "string", "description": "New customer billing address"},
                    "ship_to_address":         {"kwarg": "ship_to_address", "type": "string", "description": "New ship to address"},
                    "add_ledger_entry_ids":    {"kwarg": "add_ledger_entry_ids", "type": "array", "items": {"type": "string"}, "description": "List of SHIP ledger entries to link to this order (accepts ledger_number strings like 'SH-6884' or raw integer IDs)", "resolve": {"entity": "ledger", "search_kwarg": "search", "match_field": "ledger_number", "case_sensitive": False, "per_element": True, "passthrough_int": True}},
                    "remove_ledger_entry_ids": {"kwarg": "remove_ledger_entry_ids", "type": "array", "items": {"type": "string"}, "description": "List of SHIP ledger entries to unlink from this order (accepts ledger_number strings like 'SH-6884' or raw integer IDs)", "resolve": {"entity": "ledger", "search_kwarg": "search", "match_field": "ledger_number", "case_sensitive": False, "per_element": True, "passthrough_int": True}},
                },
                "required": ["so_number"],
            },
            {
                "action": "delete_draft",
                "name": "delete_draft_sales_order",
                "description": "Delete a sales order. Drafts are hard-deleted; live orders are soft-deleted (pending_delete=true) for review.",
                "method": "delete_as_draft",
                "params": {
                    "so_number": {"kwarg": "order_id", "type": "string", "description": "The SO number of the draft sales order to delete", "resolve": {"entity": "sales_orders", "search_kwarg": "q", "match_field": "so_number", "case_sensitive": True}},
                },
                "required": ["so_number"],
            },
            {
                "action": "read",
                "name": "get_sales_order",
                "description": "Get detailed information about a single sales order by its SO number",
                "method": "get",
                "params": {
                    "so_number": {"kwarg": "order_id", "type": "string", "description": "The SO number of the sales order to retrieve (e.g. 'SO-92'); resolved to integer ID", "resolve": {"entity": "sales_orders", "search_kwarg": "q", "match_field": "so_number", "case_sensitive": True}},
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                },
                "required": ["so_number"],
            },
        ],
    },
    "manufacturing_orders": {
        "read":         True,
        "create_draft": True,
        "update_draft": True,
        "delete_draft": True,
        "visible_fields": {"mo_number", "description", "start_date", "target_date", "is_draft", "status"},
        "tools": [
            {
                "action": "read",
                "name": "list_manufacturing_orders",
                "description": "List all manufacturing orders",
                "method": "list",
                "params": {
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                    "sort_by": {"kwarg": "sort_by", "type": "string", "description": "Field name to sort by (must be in visible_fields for this entity)"},
                    "sort_order": {"kwarg": "sort_order", "type": "string", "description": "Sort direction: 'asc' (default) or 'desc'"},
                    "limit": {"kwarg": "limit", "type": "integer", "description": "Maximum number of results (default 20)", "default": 20},
                },
                "required": [],
            },
            {
                "action": "create_draft",
                "name": "create_draft_manufacturing_order",
                "description": "Create a DRAFT manufacturing order. Draft orders must be confirmed before becoming permanent.",
                "method": "create",
                "params": {
                    "description":      {"kwarg": "description", "type": "string", "description": "Description of the manufacturing order"},
                    "start_date":       {"kwarg": "start_date", "type": "string", "description": "Start date in YYYY-MM-DD format (defaults to today)"},
                    "target_date":      {"kwarg": "target_date", "type": "string", "description": "Target completion date in YYYY-MM-DD format (defaults to start_date)"},
                    "comments":         {"kwarg": "comments", "type": "string", "description": "Optional comments"},
                    "ledger_entry_ids": {"kwarg": "ledger_entry_ids", "type": "array", "items": {"type": "string"}, "description": "List of MAKE ledger entries to link to this order (accepts ledger_number strings like 'MK-6863' or raw integer IDs)", "resolve": {"entity": "ledger", "search_kwarg": "search", "match_field": "ledger_number", "case_sensitive": False, "per_element": True, "passthrough_int": True}},
                },
                "required": ["description"],
            },
            {
                "action": "update_draft",
                "name": "update_draft_manufacturing_order",
                "description": "Update a manufacturing order as a DRAFT edit. Draft orders are modified directly; live orders get a pending draft update that must be approved or rejected.",
                "method": "update_as_draft",
                "params": {
                    "mo_number":               {"kwarg": "order_id", "type": "string", "description": "The MO number of the draft manufacturing order to update", "resolve": {"entity": "manufacturing_orders", "search_kwarg": "q", "match_field": "mo_number", "case_sensitive": True}},
                    "description":             {"kwarg": "description", "type": "string", "description": "New description"},
                    "start_date":              {"kwarg": "start_date", "type": "string", "description": "New start date in YYYY-MM-DD format"},
                    "target_date":             {"kwarg": "target_date", "type": "string", "description": "New target date in YYYY-MM-DD format"},
                    "comments":                {"kwarg": "comments", "type": "string", "description": "New comments"},
                    "add_ledger_entry_ids":    {"kwarg": "add_ledger_entry_ids", "type": "array", "items": {"type": "string"}, "description": "List of MAKE ledger entries to link to this order (accepts ledger_number strings like 'MK-6863' or raw integer IDs)", "resolve": {"entity": "ledger", "search_kwarg": "search", "match_field": "ledger_number", "case_sensitive": False, "per_element": True, "passthrough_int": True}},
                    "remove_ledger_entry_ids": {"kwarg": "remove_ledger_entry_ids", "type": "array", "items": {"type": "string"}, "description": "List of MAKE ledger entries to unlink from this order (accepts ledger_number strings like 'MK-6863' or raw integer IDs)", "resolve": {"entity": "ledger", "search_kwarg": "search", "match_field": "ledger_number", "case_sensitive": False, "per_element": True, "passthrough_int": True}},
                },
                "required": ["mo_number"],
            },
            {
                "action": "delete_draft",
                "name": "delete_draft_manufacturing_order",
                "description": "Delete a manufacturing order. Drafts are hard-deleted; live orders are soft-deleted (pending_delete=true) for review.",
                "method": "delete_as_draft",
                "params": {
                    "mo_number": {"kwarg": "order_id", "type": "string", "description": "The MO number of the draft manufacturing order to delete", "resolve": {"entity": "manufacturing_orders", "search_kwarg": "q", "match_field": "mo_number", "case_sensitive": True}},
                },
                "required": ["mo_number"],
            },
            {
                "action": "read",
                "name": "get_manufacturing_order",
                "description": "Get detailed information about a single manufacturing order by its MO number",
                "method": "get",
                "params": {
                    "mo_number": {"kwarg": "order_id", "type": "string", "description": "The MO number of the manufacturing order to retrieve (e.g. 'MO-42'); resolved to integer ID", "resolve": {"entity": "manufacturing_orders", "search_kwarg": "q", "match_field": "mo_number", "case_sensitive": True}},
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                },
                "required": ["mo_number"],
            },
        ],
    },
    "businesses": {
        "read":         True,
        "create_draft": False,
        "update_draft": False,
        "delete_draft": False,
        "visible_fields": {"id", "name", "type"},
        "tools": [
            {
                "action": "read",
                "name": "list_businesses",
                "description": "List businesses. Use query for case-insensitive substring match on name; use relationship to filter to CUSTOMER/VENDOR/BOTH.",
                "method": "list",
                "params": {
                    "query": {"kwarg": "q", "type": "string", "description": "Case-insensitive substring search on business name"},
                    "relationship": {"kwarg": "relationship", "type": "string", "description": "Filter by relationship: CUSTOMER, VENDOR, or BOTH (CUSTOMER and VENDOR also include BOTH businesses)"},
                    "limit": {"kwarg": "limit", "type": "integer", "description": "Maximum number of results (default: no limit)"},
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                    "sort_by": {"kwarg": "sort_by", "type": "string", "description": "Field name to sort by (must be in visible_fields for this entity)"},
                    "sort_order": {"kwarg": "sort_order", "type": "string", "description": "Sort direction: 'asc' (default) or 'desc'"},
                },
                "required": [],
            },
        ],
    },
    "shipments": {
        "read":         True,
        "create_draft": True,
        "update_draft": True,
        "delete_draft": True,
        "visible_fields": {"id", "shipment_number", "tracking_number", "ship_to_address", "ship_from_address", "ship_date", "comments", "business_id", "total_price", "is_draft"},
        "tools": [
            {
                "action": "read",
                "name": "list_shipments",
                "description": "List shipments (sorted most recent first). Use limit to control result size.",
                "method": "list",
                "params": {
                    "query": {"kwarg": "q", "type": "string", "description": "Search by tracking number, address, comments, or business name"},
                    "limit": {"kwarg": "limit", "type": "integer", "description": "Maximum number of results (default 20)", "default": 20},
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                    "sort_by": {"kwarg": "sort_by", "type": "string", "description": "Field name to sort by (must be in visible_fields for this entity)"},
                    "sort_order": {"kwarg": "sort_order", "type": "string", "description": "Sort direction: 'asc' (default) or 'desc'"},
                },
                "required": [],
            },
            {
                "action": "create_draft",
                "name": "create_draft_shipment",
                "description": "Create a DRAFT shipment. Draft shipments must be confirmed before becoming permanent.",
                "method": "create",
                "params": {
                    "tracking_number":  {"kwarg": "tracking_number", "type": "string", "description": "Tracking number"},
                    "ship_to_address":  {"kwarg": "ship_to_address", "type": "string", "description": "Shipping address"},
                    "ship_from_address": {"kwarg": "ship_from_address", "type": "string", "description": "Ship from address (defaults to company address if omitted)"},
                    "ship_date":        {"kwarg": "ship_date", "type": "string", "description": "Ship date in YYYY-MM-DD format"},
                    "comments":         {"kwarg": "comments", "type": "string", "description": "Optional comments"},
                    "business_name":    {"kwarg": "business_id", "type": "string", "description": "Optional business name", "resolve": {"entity": "businesses", "search_kwarg": "q", "match_field": "name", "case_sensitive": False}},
                    "ledger_entry_ids": {"kwarg": "ledger_entry_ids", "type": "array", "items": {"type": "string"}, "description": "List of SHIP ledger entries to link to this shipment (accepts ledger_number strings like 'SH-6884' or raw integer IDs)", "resolve": {"entity": "ledger", "search_kwarg": "search", "match_field": "ledger_number", "case_sensitive": False, "per_element": True, "passthrough_int": True}},
                },
                "required": ["business_name"],
            },
            {
                "action": "update_draft",
                "name": "update_draft_shipment",
                "description": "Update a shipment as a DRAFT edit. Draft shipments are modified directly; live shipments get a pending draft update that must be approved or rejected.",
                "method": "update_as_draft",
                "params": {
                    "shipment_number":         {"kwarg": "shipment_id", "type": "string", "description": "The shipment number of the draft shipment to update (e.g. 'SHP-132')", "resolve": {"entity": "shipments", "search_kwarg": "q", "match_field": "shipment_number", "case_sensitive": True}},
                    "tracking_number":         {"kwarg": "tracking_number", "type": "string", "description": "New tracking number"},
                    "ship_to_address":         {"kwarg": "ship_to_address", "type": "string", "description": "New shipping address"},
                    "ship_from_address":       {"kwarg": "ship_from_address", "type": "string", "description": "New ship from address"},
                    "ship_date":               {"kwarg": "ship_date", "type": "string", "description": "New ship date in YYYY-MM-DD format"},
                    "comments":                {"kwarg": "comments", "type": "string", "description": "New comments"},
                    "add_ledger_entry_ids":    {"kwarg": "add_ledger_entry_ids", "type": "array", "items": {"type": "string"}, "description": "List of SHIP ledger entries to link to this shipment (accepts ledger_number strings like 'SH-6884' or raw integer IDs)", "resolve": {"entity": "ledger", "search_kwarg": "search", "match_field": "ledger_number", "case_sensitive": False, "per_element": True, "passthrough_int": True}},
                    "remove_ledger_entry_ids": {"kwarg": "remove_ledger_entry_ids", "type": "array", "items": {"type": "string"}, "description": "List of SHIP ledger entries to unlink from this shipment (accepts ledger_number strings like 'SH-6884' or raw integer IDs)", "resolve": {"entity": "ledger", "search_kwarg": "search", "match_field": "ledger_number", "case_sensitive": False, "per_element": True, "passthrough_int": True}},
                },
                "required": ["shipment_number"],
            },
            {
                "action": "delete_draft",
                "name": "delete_draft_shipment",
                "description": "Delete a shipment. Drafts are hard-deleted; live shipments are soft-deleted (pending_delete=true) for review.",
                "method": "delete_as_draft",
                "params": {
                    "shipment_number": {"kwarg": "shipment_id", "type": "string", "description": "The shipment number of the draft shipment to delete (e.g. 'SHP-132')", "resolve": {"entity": "shipments", "search_kwarg": "q", "match_field": "shipment_number", "case_sensitive": True}},
                },
                "required": ["shipment_number"],
            },
            {
                "action": "read",
                "name": "get_shipment",
                "description": "Get detailed information about a single shipment by its shipment number",
                "method": "get",
                "params": {
                    "shipment_number": {"kwarg": "shipment_id", "type": "string", "description": "The shipment number of the shipment to retrieve (e.g. 'SHP-132'); resolved to integer ID", "resolve": {"entity": "shipments", "search_kwarg": "q", "match_field": "shipment_number", "case_sensitive": True}},
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                },
                "required": ["shipment_number"],
            },
        ],
    },
    "serial_numbers": {
        "read":         True,
        "create_draft": True,
        "update_draft": True,
        "delete_draft": True,
        "visible_fields": {"serial_number", "test_data", "created_at", "is_draft", "ledger_entries"},
        "tools": [
            {
                "action": "read",
                "name": "list_serial_numbers",
                "description": "List serial numbers with optional filters. Use limit to control result size.",
                "method": "list",
                "params": {
                    "query": {"kwarg": "q", "type": "string", "description": "Search by serial number"},
                    "limit": {"kwarg": "limit", "type": "integer", "description": "Maximum number of results (default 20)", "default": 20},
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                    "sort_by": {"kwarg": "sort_by", "type": "string", "description": "Field name to sort by (must be in visible_fields for this entity)"},
                    "sort_order": {"kwarg": "sort_order", "type": "string", "description": "Sort direction: 'asc' (default) or 'desc'"},
                },
                "required": [],
            },
            {
                "action": "create_draft",
                "name": "create_draft_serial_number",
                "description": "Create a DRAFT serial number. Draft serial numbers must be confirmed before becoming permanent.",
                "method": "create",
                "params": {
                    "test_data": {"kwarg": "test_data", "type": "string", "description": "Optional test data associated with the serial number"},
                },
                "required": [],
            },
            {
                "action": "update_draft",
                "name": "update_draft_serial_number",
                "description": "Update a serial number as a DRAFT edit. Draft serial numbers are modified directly; live serial numbers get a pending draft update that must be approved or rejected.",
                "method": "update_as_draft",
                "params": {
                    "serial_number": {"kwarg": "serial_number_id", "type": "string", "description": "The serial number string to update (e.g. 'SN-4')", "resolve": {"entity": "serial_numbers", "search_kwarg": "q", "match_field": "serial_number", "case_sensitive": False}},
                    "test_data": {"kwarg": "test_data", "type": "string", "description": "New test data"},
                },
                "required": ["serial_number"],
            },
            {
                "action": "delete_draft",
                "name": "delete_draft_serial_number",
                "description": "Delete a serial number. Drafts are hard-deleted; live serial numbers are soft-deleted (pending_delete=true) for review.",
                "method": "delete_as_draft",
                "params": {
                    "serial_number": {"kwarg": "serial_number_id", "type": "string", "description": "The serial number string to delete (e.g. 'SN-4')", "resolve": {"entity": "serial_numbers", "search_kwarg": "q", "match_field": "serial_number", "case_sensitive": False}},
                },
                "required": ["serial_number"],
            },
            {
                "action": "read",
                "name": "get_serial_number",
                "description": "Get detailed information about a single serial number",
                "method": "get",
                "params": {
                    "serial_number": {"kwarg": "serial_number_id", "type": "string", "description": "The serial number string to retrieve (e.g. 'SN-4'); resolved to integer ID", "resolve": {"entity": "serial_numbers", "search_kwarg": "q", "match_field": "serial_number", "case_sensitive": False}},
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                },
                "required": ["serial_number"],
            },
        ],
    },
    "designs": {
        "read":         False,
        "create_draft": False,
        "update_draft": False,
        "delete_draft": False,
        "visible_fields": set(),
        "tools": [],
    },
    "prefixes": {
        "read":         True,
        "create_draft": False,
        "update_draft": False,
        "delete_draft": False,
        "visible_fields": {"code", "description", "counter", "active"},
        "tools": [
            {
                "action": "read",
                "name": "list_prefixes",
                "description": "List all part number prefixes (categories like FAB, WID, ELC)",
                "method": "list",
                "params": {
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                    "sort_by": {"kwarg": "sort_by", "type": "string", "description": "Field name to sort by (must be in visible_fields for this entity)"},
                    "sort_order": {"kwarg": "sort_order", "type": "string", "description": "Sort direction: 'asc' (default) or 'desc'"},
                },
                "required": [],
            },
        ],
    },
    "tags": {
        "read":         True,
        "create_draft": False,
        "update_draft": False,
        "delete_draft": False,
        "visible_fields": {"id", "name", "color"},
        "tools": [
            {
                "action": "read",
                "name": "list_tags",
                "description": "List all tags used to categorize ledger entries",
                "method": "list",
                "params": {
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                    "sort_by": {"kwarg": "sort_by", "type": "string", "description": "Field name to sort by (must be in visible_fields for this entity)"},
                    "sort_order": {"kwarg": "sort_order", "type": "string", "description": "Sort direction: 'asc' (default) or 'desc'"},
                },
                "required": [],
            },
        ],
    },
    "issues": {
        "read":         True,
        "create_draft": False,
        "update_draft": False,
        "delete_draft": False,
        "visible_fields": {"entities", "counts", "issue_counts", "dismissed_count"},
        "tools": [
            {
                "action": "read",
                "name": "list_issues",
                "description": "Get entities requiring attention (drafts, overdue tasks, stock shortfalls, etc.). Returns entity details plus counts and issue_counts. When entity_type is supplied, counts and issue_counts are scoped to that type. Note: stock_shortfall issues are keyed to the ledger entry that caused them, so query with entity_type='ledger' (not 'part') to see stock problems.",
                "method": "list",
                "params": {
                    "entity_type": {"kwarg": "entity_type", "type": "string", "description": "Filter by entity type. 'ledger' covers stock_shortfall and ledger-draft issues. 'part' / 'sales_order' / 'purchase_order' / 'manufacturing_order' / 'shipment' cover their own draft and pending_delete issues."},
                    "limit":       {"kwarg": "limit", "type": "integer", "description": "Max entities to return (default 25). Counts still reflect the full set."},
                    "fields": {"type": "array", "items": {"type": "string"}, "description": "Limit response to specific fields (must be in visible_fields). Omit for all fields.", "client_only": True},
                },
                "required": [],
            },
        ],
    },
}


def can(entity, action):
    """Check if the agent is allowed to perform an action on an entity."""
    return AGENT_CAPABILITIES.get(entity, {}).get(action, False)


def visible_fields(entity):
    """Return the set of fields the agent can see for an entity."""
    return AGENT_CAPABILITIES.get(entity, {}).get("visible_fields", set())


def build_tools():
    """Generate the Anthropic API tool schema list from the capability table.

    Only includes tools whose entity+action capability flag is True.
    """
    tools = []
    for entity_name, entity_caps in AGENT_CAPABILITIES.items():
        for tool in entity_caps.get("tools", []):
            if not entity_caps.get(tool["action"], False):
                continue
            properties = {}
            for param_name, param_def in tool["params"].items():
                prop = {
                    "type": param_def["type"],
                    "description": param_def["description"],
                }
                if "items" in param_def:
                    prop["items"] = param_def["items"]
                properties[param_name] = prop
            tools.append({
                "name": tool["name"],
                "description": tool["description"],
                "input_schema": {
                    "type": "object",
                    "properties": properties,
                    "required": list(tool["required"]),
                },
            })
    return tools


def get_tool_meta(tool_name):
    """Look up (entity_name, tool_entry) for a given tool name.

    Returns None if the tool is not found in any entity.
    """
    for entity_name, entity_caps in AGENT_CAPABILITIES.items():
        for tool in entity_caps.get("tools", []):
            if tool["name"] == tool_name:
                return (entity_name, tool)
    return None


def _slim(data, keys):
    """Keep only the specified keys from a dict (or list of dicts)."""
    if isinstance(data, list):
        return [_slim(item, keys) for item in data]
    if isinstance(data, dict):
        return {k: v for k, v in data.items() if k in keys}
    return data


def _match_candidates(results, match_field, candidate, case_sensitive):
    """Return results whose match_field equals candidate (case-insensitive unless case_sensitive)."""
    if case_sensitive:
        return [r for r in results if r.get(match_field) == candidate]
    candidate_lower = candidate.lower() if isinstance(candidate, str) else candidate
    return [
        r
        for r in results
        if isinstance(r.get(match_field), str)
        and r.get(match_field).lower() == candidate_lower
    ]


def _resolve_params(client, tool_def, tool_input):
    """Resolve user-facing identifiers (strings) to integer IDs.

    For each param in the tool definition that has a 'resolve' config,
    search the specified entity resource via list() and try increasingly
    forgiving matches:
      1. Strict match on match_field (respecting case_sensitive).
      2. Case-insensitive match (e.g. 'mo-1' -> 'MO-1').
      3. Leading-zero strip on '<ALPHA>-<digits>' inputs (e.g. 'MO-01' -> 'MO-1').
      4. Bare-integer fallback for entities with a fixed prefix in
         _ENTITY_PREFIXES (manufacturing_orders/purchase_orders/sales_orders).

    tool_input is never mutated; the agent's original string stays visible
    in the tool-call trace.

    Returns (resolved, error) where resolved is {param_name: integer id} and
    error is None on success or a JSON error string on zero/multiple matches.
    """
    resolved = {}
    for param_name, param_def in tool_def.get("params", {}).items():
        if "resolve" not in param_def:
            continue
        if param_name not in tool_input:
            continue

        resolve_config = param_def["resolve"]
        entity_name = resolve_config.get("entity")
        search_kwarg = resolve_config.get("search_kwarg")
        match_field = resolve_config.get("match_field")
        case_sensitive = resolve_config.get("case_sensitive", True)
        per_element = resolve_config.get("per_element", False)
        passthrough_int = resolve_config.get("passthrough_int", False)

        user_value = tool_input[param_name]

        if per_element:
            if not isinstance(user_value, list):
                return resolved, json.dumps({
                    "error": f"{param_name} must be a list for per-element resolution"
                })
            resolved_list = []
            for idx, element in enumerate(user_value):
                if isinstance(element, int) and not isinstance(element, bool):
                    resolved_list.append(element)
                    continue
                if passthrough_int and isinstance(element, str) and element.isdigit():
                    resolved_list.append(int(element))
                    continue
                single_id, single_err = _resolve_single(
                    client, entity_name, search_kwarg, match_field,
                    case_sensitive, element,
                )
                if single_err is not None:
                    return resolved, json.dumps({
                        "error": f"{single_err} (element {idx} of {param_name})"
                    })
                resolved_list.append(single_id)
            resolved[param_name] = resolved_list
            continue

        single_id, single_err = _resolve_single(
            client, entity_name, search_kwarg, match_field,
            case_sensitive, user_value,
        )
        if single_err is not None:
            return resolved, json.dumps({"error": single_err})
        resolved[param_name] = single_id

    return resolved, None


def _resolve_single(client, entity_name, search_kwarg, match_field, case_sensitive, user_value):
    """Resolve one user-facing value to an integer id using the candidate ladder.

    Returns (id, None) on unique match, (None, error_message) on zero/multiple matches.
    """
    resource = getattr(client, entity_name)

    candidates = [user_value]
    if isinstance(user_value, str):
        m = re.fullmatch(r"([A-Za-z]+)-0*(\d+)", user_value)
        if m:
            canonical = f"{m.group(1)}-{m.group(2)}"
            if canonical != user_value:
                candidates.append(canonical)
        if user_value.isdigit() and entity_name in _ENTITY_PREFIXES:
            candidates.append(f"{_ENTITY_PREFIXES[entity_name]}-{user_value}")

    matches = []
    for idx, candidate in enumerate(candidates):
        if search_kwarg is None:
            results = resource.list(limit=500)
        else:
            results = resource.list(**{search_kwarg: candidate})
        strict = case_sensitive and idx == 0
        matches = _match_candidates(results, match_field, candidate, strict)
        if matches:
            break
        if idx == 0 and case_sensitive:
            matches = _match_candidates(results, match_field, candidate, False)
            if matches:
                break

    if len(matches) == 0:
        return None, f"No {entity_name} found matching {match_field}={user_value}"

    if len(matches) > 1:
        match_values = [str(m.get(match_field)) for m in matches[:5]]
        return None, f"Multiple {entity_name} match {match_field}={user_value}: {', '.join(match_values)}"

    return matches[0]["id"], None


def execute_tool(client, tool_name, tool_input):
    """Generic tool dispatcher.

    Resolves tool_name to entity + method, checks capability, validates
    sort/field inputs, resolves user-facing identifiers to integer IDs,
    builds kwargs from the param mapping, calls the borgprime_client method,
    and returns a JSON-stringified, field-slimmed result.

    Returns a JSON string (either the result or an error object).
    """
    meta = get_tool_meta(tool_name)
    if meta is None:
        return json.dumps({"error": f"Tool '{tool_name}' is not enabled"})

    entity_name, tool_def = meta

    if not can(entity_name, tool_def["action"]):
        return json.dumps({"error": f"Tool '{tool_name}' is not enabled"})

    all_visible = visible_fields(entity_name)

    # Validate sort_by / sort_order before any HTTP work.
    if "sort_by" in tool_input:
        sort_by_value = tool_input["sort_by"]
        if sort_by_value not in all_visible:
            return json.dumps({"error": f"sort_by '{sort_by_value}' is not a valid field for {entity_name}"})
    if "sort_order" in tool_input:
        if tool_input["sort_order"] not in ("asc", "desc"):
            return json.dumps({
                "error": f"sort_order '{tool_input['sort_order']}' is invalid; must be 'asc' or 'desc'"
            })

    # Validate requested fields against visible_fields whitelist.
    requested_fields = tool_input.get("fields")
    if requested_fields:
        unknown = [f for f in requested_fields if f not in all_visible]
        if unknown:
            return json.dumps({
                "error": (
                    f"Unknown field(s): {', '.join(unknown)}. "
                    f"Valid fields for {entity_name}: {', '.join(sorted(all_visible))}"
                )
            })

    # Resolve user-facing identifiers to integer IDs. _resolve_params does
    # NOT mutate tool_input — it returns a separate resolved dict so the
    # agent's original string stays visible in the tool-call trace.
    resolved, resolve_error = _resolve_params(client, tool_def, tool_input)
    if resolve_error is not None:
        return resolve_error

    # Build kwargs from tool_input using param mapping, excluding client_only params.
    # Resolved values (integer ids) override tool_input (agent's original strings).
    kwargs = {}
    for param_name, param_def in tool_def["params"].items():
        if param_def.get("client_only", False):
            continue
        kwarg_name = param_def.get("kwarg", param_name)
        if param_name in resolved:
            kwargs[kwarg_name] = resolved[param_name]
        elif param_name in tool_input:
            kwargs[kwarg_name] = tool_input[param_name]
        elif "default" in param_def:
            kwargs[kwarg_name] = param_def["default"]

    # Default sort_order=asc when sort_by was supplied without sort_order
    if "sort_by" in tool_input and "sort_order" not in tool_input:
        sort_order_def = tool_def["params"].get("sort_order")
        if sort_order_def is not None:
            kwargs[sort_order_def.get("kwarg", "sort_order")] = "asc"

    resource = getattr(client, entity_name)
    method = getattr(resource, tool_def["method"])
    result = method(**kwargs)

    # Delete actions: distinguish hard-delete vs soft-delete (pending_delete).
    if tool_def["action"] == "delete_draft":
        identifier = next((str(tool_input[p]) for p in tool_def["params"] if p in tool_input), "unknown")
        soft = result if isinstance(result, dict) else {}
        if isinstance(soft.get("updated"), dict):
            soft = soft["updated"]
        if soft.get("pending_delete") is True:
            return json.dumps({"status": "pending_delete", "entity": entity_name, "id": identifier})
        return json.dumps({"status": "deleted", "entity": entity_name, "id": identifier})

    # Unwrap nested response if tool declares a response_key
    response_key = tool_def.get("response_key")
    if response_key and isinstance(result, dict) and response_key in result:
        result = result[response_key]

    # Detect pending_update BEFORE slimming (pre_update_snapshot is not in visible_fields).
    is_pending_update = (
        tool_def["action"] == "update_draft"
        and isinstance(result, dict)
        and result.get("pre_update_snapshot") is not None
    )

    # Apply field selection: visible_fields by default, or the validated subset.
    effective_fields = set(requested_fields) & all_visible if requested_fields else all_visible
    slimmed = _slim(result, effective_fields)

    if is_pending_update and isinstance(slimmed, dict):
        slimmed = {**slimmed, "status": "pending_update"}

    return json.dumps(slimmed)

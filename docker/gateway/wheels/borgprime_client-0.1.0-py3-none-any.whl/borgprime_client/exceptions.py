"""Exception classes for borgprime_client."""


class BorgPrimeError(Exception):
    """Base exception for all BorgPrime client errors."""
    pass


class DraftOnlyError(BorgPrimeError):
    """Raised when attempting to mutate a non-draft entity."""
    pass


class NotFoundError(BorgPrimeError):
    """Raised on HTTP 404."""
    pass


class ServerError(BorgPrimeError):
    """Raised on HTTP 5xx."""
    pass


class TimeoutError(BorgPrimeError):
    """Raised when the request times out. Use a narrower filter or increase timeout."""
    pass


class ConnectionError(BorgPrimeError):
    """Raised when the backend is unreachable."""
    pass

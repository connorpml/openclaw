"""BorgPrime Python client library."""

from .client import BorgPrimeClient
from .capabilities import (
    AGENT_CAPABILITIES,
    can,
    visible_fields,
    build_tools,
    get_tool_meta,
    execute_tool,
)
from .exceptions import (
    BorgPrimeError,
    DraftOnlyError,
    NotFoundError,
    ServerError,
    TimeoutError,
    ConnectionError,
)

__all__ = [
    "BorgPrimeClient",
    "AGENT_CAPABILITIES",
    "can",
    "visible_fields",
    "build_tools",
    "get_tool_meta",
    "execute_tool",
    "BorgPrimeError",
    "DraftOnlyError",
    "NotFoundError",
    "ServerError",
    "TimeoutError",
    "ConnectionError",
]

"""Schema → Click option translation.

Consumes the tool entries produced by ``borgprime_client.capabilities.build_tools``
and emits Click options. Also provides :func:`collect_params` which turns the
raw Click kwargs for a single invocation into the params dict that
``execute_tool`` expects — dropping unsupplied options and normalizing arrays.
"""

from __future__ import annotations

from typing import Any, Dict, Mapping, Tuple

import click


_CLICK_TYPES = {
    "string": str,
    "integer": int,
}


def option_name(property_name: str) -> str:
    """Return the kebab-case flag name (without leading dashes) for a schema property."""
    return property_name.replace("_", "-")


def _click_kwargs_for_property(
    property_name: str,
    prop_schema: Mapping[str, Any],
    required: bool,
    schema_default: Any,
    has_schema_default: bool,
) -> Tuple[str, Dict[str, Any]]:
    """Build the (declaration, kwargs) pair for a single ``click.option`` call.

    Schema defaults are NOT passed to Click — ``execute_tool`` in the kernel
    owns default application, and we want unsupplied options to be omitted
    from the params dict so the kernel's handling runs. The schema default
    is surfaced in the help text only.
    """
    flag = f"--{option_name(property_name)}"
    help_text = prop_schema.get("description", "")
    if has_schema_default:
        help_text = f"{help_text}  [default: {schema_default}]".strip()

    kwargs: Dict[str, Any] = {"help": help_text}

    prop_type = prop_schema.get("type", "string")
    if prop_type == "array":
        kwargs["multiple"] = True
        kwargs["type"] = str
    else:
        kwargs["type"] = _CLICK_TYPES.get(prop_type, str)

    if required:
        kwargs["required"] = True

    return flag, kwargs


def iter_schema_options(tool: Mapping[str, Any], capability_params: Mapping[str, Mapping[str, Any]]):
    """Yield ``(property_name, flag, click_kwargs)`` for every option on a tool.

    ``capability_params`` is the raw ``params`` dict from ``AGENT_CAPABILITIES``
    for this tool — we read ``default`` from there only to annotate help text.
    """
    props = tool["input_schema"].get("properties", {})
    required = set(tool["input_schema"].get("required", []))
    for prop_name, prop_schema in props.items():
        cap_param = capability_params.get(prop_name, {})
        has_default = "default" in cap_param
        default = cap_param.get("default")
        flag, kwargs = _click_kwargs_for_property(
            prop_name,
            prop_schema,
            required=prop_name in required,
            schema_default=default,
            has_schema_default=has_default,
        )
        yield prop_name, flag, kwargs


def _normalize_array(value: Tuple[str, ...]) -> list:
    """Split comma-separated tokens and drop empties from a ``multiple=True`` tuple."""
    out = []
    for item in value:
        if item is None:
            continue
        for token in str(item).split(","):
            if token:
                out.append(token)
    return out


def collect_params(
    tool: Mapping[str, Any],
    click_kwargs: Mapping[str, Any],
) -> Dict[str, Any]:
    """Translate Click's kwargs for one invocation into the kernel's params dict.

    - Options the user did not supply are omitted (value is ``None`` or, for
      arrays, an empty tuple).
    - Array options are flattened + comma-split.
    - Keys use the original schema property name (underscores), not the
      kebab-case flag name; Click already normalizes ``--foo-bar`` to
      ``foo_bar`` when it passes kwargs, which matches what we want.
    """
    props = tool["input_schema"].get("properties", {})
    params: Dict[str, Any] = {}
    for prop_name, prop_schema in props.items():
        if prop_name not in click_kwargs:
            continue
        value = click_kwargs[prop_name]
        if prop_schema.get("type") == "array":
            # Click passes `()` when --foo is not supplied; any non-empty tuple
            # means the user did supply the flag (possibly with an empty string
            # that normalizes to `[]`). Preserve explicit-empty so the backend
            # can tell "don't touch" apart from "clear all".
            if not value:
                continue
            params[prop_name] = _normalize_array(value)
        else:
            if value is None:
                continue
            params[prop_name] = value
    return params

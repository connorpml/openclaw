"""Click entry point — codegens a subcommand per enabled tool from ``AGENT_CAPABILITIES``.

Every subcommand funnels into :func:`borgprime_client.capabilities.execute_tool`.
No per-tool glue, no parallel safeguard table.
"""

from __future__ import annotations

import json
import os
import sys
from typing import Any, Callable, Dict

import click

from borgprime_client.client import BorgPrimeClient
from borgprime_client.capabilities import AGENT_CAPABILITIES, build_tools, execute_tool
from borgprime_client.exceptions import BorgPrimeError

from . import __version__
from ._params import collect_params, iter_schema_options, option_name


DEFAULT_URL = "http://127.0.0.1:5000"
_CTX_CLIENT_FACTORY = "client_factory"
_CTX_EXECUTE_TOOL = "execute_tool"


def _default_client_factory(url: str) -> BorgPrimeClient:
    return BorgPrimeClient(url)


def _resolve_url(url_option: str | None) -> str:
    if url_option:
        return url_option
    env = os.environ.get("BORGPRIME_URL")
    if env:
        return env
    return DEFAULT_URL


def _capability_params_for(tool_name: str) -> Dict[str, Dict[str, Any]]:
    """Locate the raw ``params`` dict for a tool inside ``AGENT_CAPABILITIES``.

    ``build_tools()`` strips out ``default`` and other kernel-only bits when it
    constructs the Anthropic input_schema, so we consult the capability table
    directly to recover defaults during option construction.
    """
    for entity_caps in AGENT_CAPABILITIES.values():
        for tool in entity_caps.get("tools", []):
            if tool["name"] == tool_name:
                return tool.get("params", {})
    return {}


def _make_command(tool: Dict[str, Any]) -> click.Command:
    """Build one Click command for a single tool schema entry."""
    tool_name = tool["name"]
    cap_params = _capability_params_for(tool_name)

    def callback(**click_kwargs: Any) -> None:
        ctx = click.get_current_context()
        url = _resolve_url(ctx.obj.get("url"))
        client_factory: Callable[[str], BorgPrimeClient] = ctx.obj.get(
            _CTX_CLIENT_FACTORY, _default_client_factory
        )
        exec_fn: Callable[..., str] = ctx.obj.get(_CTX_EXECUTE_TOOL, execute_tool)

        params = collect_params(tool, click_kwargs)
        client = client_factory(url)
        try:
            result = exec_fn(client, tool_name, params)
        except BorgPrimeError as err:
            click.echo(json.dumps({"error": str(err)}), err=True)
            sys.exit(1)
        click.echo(result, nl=True)

    cmd = click.Command(
        name=tool_name.replace("_", "-"),
        help=tool.get("description", ""),
        callback=callback,
    )

    for prop_name, flag, kwargs in iter_schema_options(tool, cap_params):
        # Explicit dest avoids any ambiguity between kebab flag and snake key.
        opt = click.Option([flag, prop_name], **kwargs)
        cmd.params.append(opt)

    return cmd


def _build_group() -> click.Group:
    @click.group(help="BorgPrime CLI — whitelisted agent tools for shell and scripts.")
    @click.option(
        "--url",
        default=None,
        help=f"Base URL of the BorgPrime backend. Overrides BORGPRIME_URL (default {DEFAULT_URL}).",
    )
    @click.version_option(__version__, prog_name="borgprime")
    @click.pass_context
    def group(ctx: click.Context, url: str | None) -> None:
        ctx.ensure_object(dict)
        ctx.obj["url"] = url
        ctx.obj.setdefault(_CTX_CLIENT_FACTORY, _default_client_factory)
        ctx.obj.setdefault(_CTX_EXECUTE_TOOL, execute_tool)

    for tool in build_tools():
        group.add_command(_make_command(tool))

    return group


main = _build_group()


__all__ = ["main", "DEFAULT_URL"]

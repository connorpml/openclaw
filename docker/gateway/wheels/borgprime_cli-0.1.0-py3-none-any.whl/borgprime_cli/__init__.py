"""BorgPrime CLI — Click adapter over the borgprime_client capability kernel."""

__version__ = "0.1.0"
